/* © 2021 AO Kaspersky Lab */
#ifndef _PUBLISHER_GENERAL_H
#define _PUBLISHER_GENERAL_H

namespace app {
constexpr const char *AppTag = "[Subscriber] ";
}

#endif // _PUBLISHER_GENERAL_H