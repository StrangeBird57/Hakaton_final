#ifndef _GPIO_MODULE_H
#define _GPIO_MODULE_H

int gpiomain(int time, char** cmd);

#endif
