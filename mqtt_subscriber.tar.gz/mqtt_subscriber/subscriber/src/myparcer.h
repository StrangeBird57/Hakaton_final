#ifndef _PARCER_MODULE_H
#define _PARCER_MODULE_H

int parcermain(const std::string& cmd);

#endif
